﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c_sharpAssessment1
{
    class Book
    {
        int bookid;
        string title;
        double price;
        string booktype;
        public Book(int Bookid, string Title, double Price, string Booktype)
        {
            bookid = Bookid;
            title = Title;
            price = Price;
            booktype = Booktype;
        }
        public int Bookid{get { return bookid; }set { bookid = value; } }
        public string Title { get { return title; } set { title = value; } }
        public double Price { get { return price; } set { price = value; } }
        public string Booktype { get { return booktype; } set { booktype = value; } }
    }
    static void Main()
    {
        Book Obj = new Book(1001, "Time", 30,"Magazine");
        Console.ReadKey();
    }
}
